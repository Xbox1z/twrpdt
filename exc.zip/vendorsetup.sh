#
# Copyright (C) 2023 The Android Open Source Project
# Copyright (C) 2023 SebaUbuntu's #MODE# device tree generator
#
# SPDX-License-Identifier: Apache-2.0
#

add_lunch_combo #MODE#_#DEVICE#-user
add_lunch_combo #MODE#_#DEVICE#-userdebug
add_lunch_combo #MODE#_#DEVICE#-eng
